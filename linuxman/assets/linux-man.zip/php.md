php
===

PHP语言的命令行接口

## 补充说明

**php命令** 是流行的Web开发语言PHP的命令行接口，可以使用PHP语言开发基于命令行的系统管理脚本程序。

###  语法

```shell
php(选项)(参数)
```

###  选项

```shell
-a：进入交互模式；
-c：指定“php.ini”的搜索路径。
```

###  参数

文件：要执行的php脚本。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->