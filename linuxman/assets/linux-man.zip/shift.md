shift
===

移动位置参数。

## 概要

```shell
shift [n]
```

## 主要用途

- 将位置参数`$n, $n+1...`重命名为`$1, $2...`。

## 参数

n（可选）：大于等于1且小于等于参数个数的整数，默认为1。

## 返回值

返回成功除非n大于参数个数或n小于1以及其他非法值。

## 例子

假设我们的脚本文件（test.sh）如下：

```shell
#!/usr/bin/env bash
# 显示前三个位置参数。
echo "$1 $2 $3"
# 移除前两个位置参数，并将$3重命名为$1，之后的以此类推。
shift 2
echo "$1 $2 $3"
```

在终端执行该脚本：

```shell
sh test.sh q w e r t
```

返回信息如下：

```shell
q w e
e r t
```

### 注意

1. 该命令是bash内建命令，相关的帮助信息请查看`help`命令。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->
