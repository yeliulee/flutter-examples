kernelversion
===

打印当前内核的主版本号

## 补充说明

**kernelversion命令** 用于打印当前内核的主版本号。

###  语法

```shell
kernelversion
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->