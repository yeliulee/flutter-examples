ftptop
===

proftpd服务器的连接状态

## 补充说明

**ftptop命令** 类似于top命令的显示风格显示proftpd服务器的连接状态。

###  语法

```shell
ftptop(选项)
```

###  选项

```shell
-D：过滤正在下载的会话；
-S：仅显示指定虚拟主机的连接状态；
-d：指定屏幕刷新时间，默认
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->