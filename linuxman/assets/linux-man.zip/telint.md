telint
===

切换当前正在运行系统的运行等级

## 补充说明

**telint命令** 用于切换当前正在运行的Linux系统的运行等级。

###  语法

```shell
telint(选项)(参数)
```

###  选项

```shell
-t：指定等待的秒数。
```

###  参数

运行等级：指定要切换的运行等级。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->