lpc
===

命令行方式打印机控制程序

## 补充说明

**lpc命令** 式命令行方式打印机控制程序，有5个内置命令。

###  语法

```shell
lpc
```

###  实例

```shell
[root@localhost ~]# lpc
lpc> ?         
命令可能是缩写。命令是：

exit    help    quit    status  ?
lpc> exit
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->