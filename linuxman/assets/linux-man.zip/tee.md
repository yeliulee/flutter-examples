tee
===

从标准输入读取数据并重定向到标准输出和文件。

## 概要

```shell
tee [OPTION]... [FILE]...
```

## 主要用途

- 需要同时查看数据内容并输出到文件时使用。

## 参数

FILE（可选）：要输出的文件，可以为一或多个。

## 选项 

```shell
长选项与短选项等价

-a, --append               追加到文件中而不是覆盖。
-i, --ignore-interrupts    忽略中断信号（Ctrl+c中断操作无效）。
-p                         诊断写入非管道的错误。
--output-error[=MODE]      设置写错误时的行为，请查看下方的MODE部分。
--help                     显示帮助信息并退出。
--version                  显示版本信息并退出。

MODE决定了当出现写错误时的输出行为，可用的MODE如下：

'warn'           当写入到任何输出报错时诊断。
'warn-nopipe'    当写入到任何输出（而不是管道）报错时诊断。
'exit'           当写入到任何输出报错时退出。
'exit-nopipe'    当写入到任何输出（而不是管道）报错时退出。

-p选项的指定的默认MODE为'warn-nopipe'。
当'--output-error'没有在选项中时，默认的操作是当写入到管道报错时立刻退出，诊断错误信息并写入到非管道输出。
```

## 返回值

返回状态为成功除非给出了非法选项或非法参数。

## 例子 

```shell
# 将进程信息通过管道输出到标准输出（终端）并覆盖写入到文件中。
ps -ef |tee info_a.log info_b.log

# 将进程信息通过管道输出到标准输出（终端）并追加写入到文件中。
ps -ef |tee -a info_a.log info_b.log
```

### 注意

1. 该命令是`GNU coreutils`包中的命令，相关的帮助信息请查看`man -s 1 tee`或`info coreutils 'tee invocation'`。
2. 存在缓存机制，每1024个字节将输出一次。若从管道接收输入数据，应该是缓冲区满，才将数据转存到指定的文件中。若文件内容不到1024个字节，则接收从标准输入设备读入的数据后，将刷新一次缓冲区，并转存数据到指定文件。

<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->
