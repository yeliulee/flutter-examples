perl
===

perl语言解释器

## 补充说明

**perl命令** 是perl语言解释器，负责解释执行perl语言程序。

###  语法

```shell
perl(选项)(参数)
```

###  选项

```shell
-w：输出有用的警告信息；
-U：允许不安全的操作；
-c：仅检查文件的语法；
-d：在调试下运行脚本程序。
```

###  参数

文件：要运行的perl脚本程序。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->