dris
===

显示和清空目录堆栈中的内容

## 补充说明

**dris命令** 用于显示和清空目录堆栈中的内容。

###  语法

```shell
dris(选项)
```

###  选项

```shell
+n：显示从左边算起第n笔的目录；
-n：显示从右边算起第n笔的目录；
-l：显示目录完整的记录。
```


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->