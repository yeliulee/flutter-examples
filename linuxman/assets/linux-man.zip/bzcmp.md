bzcmp
===

比较两个压缩包中的文件

## 补充说明

**bzcmp命令** 主要功能是在不真正解压缩.bz2压缩包的情况下，比较两个压缩包中的文件，省去了解压缩后在调用cmp命令的过程。

###  语法

```shell
bzcmp(参数)
```

###  参数

* 文件1：指定要比较的第一个.bz2压缩包；
* 文件2：指定要比较的第二个.bz2压缩包。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->