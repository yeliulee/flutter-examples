cupsenable
===

启动指定的打印机

## 补充说明

**cupsenable命令** 用于启动指定的打印机。

###  语法

```shell
cupsenable(选项)(参数)
```

###  选项

```shell
-E：当连接到服务器时强制使用加密；
-U：指定连接服务器时使用的用户名；
-u：指定打印任务所属的用户；
-h：指定连接的服务器名和端口号；
```

###  参数

目标：指定目标打印机。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->