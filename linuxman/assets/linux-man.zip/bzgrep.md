bzgrep
===

使用正则表达式搜索.bz2压缩包中文件

## 补充说明

**bzgrep命令** 使用正则表达式搜索“.bz2”压缩包中文件，将匹配的行显示到标注输出。

###  语法

```shell
bzgrep(参数)
```

###  参数

*   搜索模式：指定要搜索的模式；
*   .bz2文件：指定要搜索的.bz2压缩包。


<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->