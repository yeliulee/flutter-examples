tac
===

连接多个文件并以行为单位反向打印到标准输出。

## 概要

```shell
tac [OPTION]... [FILE]...
```

## 主要用途

- 按行为单位反向显示文件内容，如果没有文件或文件为`-`则读取标准输入。
- 处理多个文件时，依次将每个文件反向显示，而不是将所有文件连在一起再反向显示。


## 参数

FILE（可选）：要处理的文件，可以为一或多个。

## 选项 

```shell
长选项与短选项等价

-b, --before              在之前而不是之后连接分隔符。
-r, --regex               将分隔符作为基础正则表达式（BRE）处理。
-s, --separator=STRING    使用STRING作为分隔符代替默认的换行符。
--help                    显示帮助信息并退出。
--version                 显示版本信息并退出。
```

## 返回值

返回状态为成功除非给出了非法选项或非法参数。

## 例子 

```shell
# 选自官方info文档的例子：
# 一个接着一个字符的反转一个文件：
tac -r -s 'x\|[^x]' test.log

# 关于-b选项：
seq 1 3 |tac
# 输出
3
2
1
# 使用-b选项：
seq 1 3 |tac -b
# 输出，注意21后面没有换行符：


3
21
# 前一个例子相当于将 '1\n2\n3\n' 转换为 '3\n2\n1\n'
# 前一个例子相当于将 '1\n2\n3\n' 转换为 '\n\n3\n21'
```

### 注意

1. 该命令是`GNU coreutils`包中的命令，相关的帮助信息请查看`man -s 1 tac`或`info coreutils 'tac invocation'`。
2. 关于基础正则表达式（BRE）的内容，详见`man -s 1 grep`的`REGULAR EXPRESSIONS`段落。

<!-- Linux命令行搜索引擎：https://jaywcjlove.github.io/linux-command/ -->
